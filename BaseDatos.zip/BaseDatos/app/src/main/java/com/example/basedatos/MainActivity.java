package com.example.basedatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText codigo;
    private EditText descripcion;
    private EditText precio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        codigo = (EditText) findViewById(R.id.txtCodigo);
        descripcion = (EditText) findViewById(R.id.txtDescripcion);
        precio = (EditText) findViewById(R.id.txtPrecio);
    }

    public void guardar(View view){
        AdminSQLite admin = new AdminSQLite(this, "administrador", null, 1);
        SQLiteDatabase baseDatos = admin.getWritableDatabase();

        String codi = codigo.getText().toString();
        String descripc = descripcion.getText().toString();
        String preci = precio.getText().toString();

        if(!codi.isEmpty() && !descripc.isEmpty() && !preci.isEmpty()){
            ContentValues registro = new ContentValues();

            registro.put("codigo", codi);
            registro.put("descripcion", descripc);
            registro.put("precio", preci);

            baseDatos.insert("articulos", null, registro );
            baseDatos.close();

            codigo.setText("");
            descripcion.setText("");
            precio.setText(" ");

            Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();

        }else{
            Toast.makeText(this, "Debe diligenciar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

    public void buscar(View view){
        AdminSQLite admin = new AdminSQLite(this, "administrador", null,1);
        SQLiteDatabase baseDatos = admin.getWritableDatabase();

        String codi = codigo.getText().toString();

        if(!codi.isEmpty()){
            Cursor fila = baseDatos.rawQuery("select descripcion, precio from articulos where codigo ="+ codi, null);
            if(fila.moveToFirst()){
                descripcion.setText(fila.getString(0));
                precio.setText(fila.getString(1));
                baseDatos.close();
            }else{
                Toast.makeText(this, "No existe el producto", Toast.LENGTH_SHORT).show();
                baseDatos.close();
            }
        }else{
            Toast.makeText(this, "Debe ingreasar el codigo del producto", Toast.LENGTH_SHORT).show();
        }
    }

    public void eliminar(View view){
        AdminSQLite admin = new AdminSQLite(this, "administrador", null,1);
        SQLiteDatabase baseDatos = admin.getWritableDatabase();

        String codi = codigo.getText().toString();

        if(!codi.isEmpty()){
            int cantidad = baseDatos.delete("articulos", "codigo="+codi, null);
            baseDatos.close();
            codigo.setText("");
            descripcion.setText("");
            precio.setText("");

            if(cantidad == 1){
                Toast.makeText(this, "Articulo eliminado correctamente", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "No existe el producto", Toast.LENGTH_SHORT).show();
                baseDatos.close();
            }
        }else{
            Toast.makeText(this, "Debe ingreasar el codigo del producto", Toast.LENGTH_SHORT).show();
        }
    }

    public void actualizar(View view){
        AdminSQLite admin = new AdminSQLite(this, "administrador", null, 1);
        SQLiteDatabase baseDatos = admin.getWritableDatabase();

        String codi = codigo.getText().toString();
        String descrip = descripcion.getText().toString();
        String preci = precio.getText().toString();

        if(!codi.isEmpty() && !descrip.isEmpty() && !preci.isEmpty()){

            ContentValues registro = new ContentValues();
            registro.put("codigo", codi);
            registro.put("descripcion", descrip);
            registro.put("precio", preci);

            int cantidad = baseDatos.update("articulos", registro, "codigo ="+ codi, null);
            baseDatos.close();

            if(cantidad == 1){
                codigo.setText("");
                descripcion.setText("");
                precio.setText("");
                Toast.makeText(this, "Articulo actualizado correctamente", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this, "No existe el producto", Toast.LENGTH_SHORT).show();
                baseDatos.close();
            }
        }else{
            Toast.makeText(this, "Debe diligenciar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }


}
