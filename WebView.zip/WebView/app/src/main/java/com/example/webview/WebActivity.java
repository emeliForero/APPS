package com.example.webview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebActivity extends AppCompatActivity {

     WebView viewVeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        viewVeb = (WebView) findViewById(R.id.web);
        String sitio_web = getIntent().getStringExtra("sitio_web");
        viewVeb.setWebViewClient(new WebViewClient());
        viewVeb.loadUrl("http://"+ sitio_web);
    }

    public void cerrar(View view){
     finish();

    }
}
