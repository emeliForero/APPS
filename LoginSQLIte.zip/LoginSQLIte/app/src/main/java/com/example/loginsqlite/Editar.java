package com.example.loginsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Editar extends AppCompatActivity  implements View.OnClickListener{
    EditText txtUsuario, txtContrasena, txtNombres, txtApellidos;
    Button btnEditar, btnCancelar;
    int id = 0;
    Usuario u;
    daoUsuario dao;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);

        txtUsuario = (EditText) findViewById(R.id.txtEmail0);
        txtContrasena = (EditText) findViewById(R.id.txtPassword0);
        txtNombres = (EditText) findViewById(R.id.txtNombres0);
        txtApellidos = (EditText) findViewById(R.id.txtApellidos0);
        btnEditar = (Button) findViewById(R.id.btnEditar0);
        btnCancelar = (Button) findViewById(R.id.btnCancelar0);
        btnEditar.setOnClickListener(this);
        btnCancelar.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();
        id = bundle.getInt("id");
        dao = new daoUsuario(this);
        u = dao.getUsuarioById(id);

        txtUsuario.setText(u.getEmail());
        txtContrasena.setText(u.getPassword());
        txtNombres.setText(u.getNombres());
        txtApellidos.setText(u.getApellidos());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnEditar0:

                u.setEmail(txtUsuario.getText().toString());
                u.setPassword(txtContrasena.getText().toString());
                u.setNombres(txtNombres.getText().toString());
                u.setApellidos(txtApellidos.getText().toString());

                if(!u.isNull()){
                    Toast.makeText(Editar.this, "Error! Campos vacios", Toast.LENGTH_SHORT).show();
                }else if(dao.updateUsuario(u)){
                    Toast.makeText(this, "Actualizacion Exitosa", Toast.LENGTH_SHORT).show();
                    Intent intent1 = new Intent(Editar.this, Inicio.class);
                    startActivity(intent1);

                }else{
                    Toast.makeText(Editar.this, "No se puede actualizar!!", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.btnCancelar0:
                Intent intent2 = new Intent(Editar.this, Inicio.class);
                startActivity(intent2);
                break;


        }
    }
}
