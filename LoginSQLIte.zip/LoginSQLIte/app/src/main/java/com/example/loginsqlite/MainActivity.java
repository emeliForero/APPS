
package com.example.loginsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText txtUsuario, txtContraseña;
    Button btnIngresar, btnRegistrar;
    daoUsuario dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txtUsuario = (EditText) findViewById(R.id.txtEmail1);
        txtContraseña = (EditText) findViewById(R.id.txtPassword1);
        btnIngresar = (Button) findViewById(R.id.btnIngresar1);
        btnRegistrar = (Button) findViewById(R.id.btnRegistrar1);

        btnIngresar.setOnClickListener(this);
        btnRegistrar.setOnClickListener(this);

        dao = new daoUsuario(this);
    }

    @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.btnIngresar1:
                String us = txtUsuario.getText().toString();
                String pass = txtContraseña.getText().toString();

                if(us.equals("")&& pass.equals("")){
                    Toast.makeText(MainActivity.this, "Error! Campos Vacios", Toast.LENGTH_SHORT).show();
                }else if(dao.login(us, pass) == 1){
                    Usuario usu = dao.getUsuario(us, pass);
                    Toast.makeText(MainActivity.this, "Datos Correctos", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Inicio.class);
                    intent.putExtra("id",usu.getId());
                    startActivity(intent);
                    finish();
                }

                break;

            case R.id.btnRegistrar1:
                Intent intent = new Intent(MainActivity.this, Registrar.class);
                startActivity(intent);
                finish();
                break;
        }
    }
}
