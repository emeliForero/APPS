package com.example.loginsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registrar extends AppCompatActivity implements View.OnClickListener {
    EditText txtUsuario, txtContraseña, txtApellidos, txtNombres;
    Button btnCrear, btnCancelar;
    daoUsuario dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        txtUsuario = (EditText) findViewById(R.id.txtEmail2);
        txtContraseña = (EditText) findViewById(R.id.txtPassword2);
        txtNombres = (EditText) findViewById(R.id.txtNombres2);
        txtApellidos = (EditText) findViewById(R.id.txtApellidos2);
        btnCrear = (Button) findViewById(R.id.btnCrear2);
        btnCancelar = (Button) findViewById(R.id.btnCancelar2);
        btnCrear.setOnClickListener(this);
        btnCancelar.setOnClickListener(this);

        dao = new daoUsuario(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnCrear2:

                Usuario u = new Usuario();
                u.setEmail(txtUsuario.getText().toString());
                u.setPassword(txtContraseña.getText().toString());
                u.setNombres(txtNombres.getText().toString());
                u.setApellidos(txtApellidos.getText().toString());

                if(!u.isNull()){
                    Toast.makeText(Registrar.this, "Error! Campos vacios", Toast.LENGTH_SHORT).show();
                }else if(dao.insertarUsuario(u)){
                    Toast.makeText(Registrar.this, "Registro Exitoso", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Registrar.this, MainActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(Registrar.this, "Usuario ya esta registrado!!", Toast.LENGTH_SHORT).show();
                }


                break;

            case R.id.btnCancelar2:

                Intent intent = new Intent(Registrar.this, MainActivity.class);
                startActivity(intent);
                finish();
                break;
        }

    }
}
