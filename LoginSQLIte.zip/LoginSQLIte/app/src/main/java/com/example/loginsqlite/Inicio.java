package com.example.loginsqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Inicio extends AppCompatActivity implements View.OnClickListener{

    Button btnEditar, btnEliminar, btnSalir, btnMostrar;
    TextView txtNombre;
    int id = 0;
    Usuario u;
    daoUsuario dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        btnEditar = (Button) findViewById(R.id.btnEditar3);
        btnEliminar = (Button) findViewById(R.id.btnEliminar3);
        btnMostrar = (Button) findViewById(R.id.btnMostrar3);
        btnSalir = (Button) findViewById(R.id.btnSalir3);
        txtNombre = (TextView) findViewById(R.id.txtBienvenido);

        btnEditar.setOnClickListener(this);
        btnEliminar.setOnClickListener(this);
        btnMostrar.setOnClickListener(this);
        btnSalir.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();
        id = bundle.getInt("id");
        dao = new daoUsuario(this);
        u = dao.getUsuarioById(id);
        txtNombre.setText("Bienvenido " + u.getNombres() +" "+ u.getApellidos());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnEditar3:

                Usuario usu = dao.getUsuario(u.getEmail(), u.getPassword());
                Intent intent1 = new Intent(Inicio.this, Editar.class);
                intent1.putExtra("id", usu.getId());
                startActivity(intent1);
                break;
            case R.id.btnEliminar3:
                AlertDialog.Builder b = new AlertDialog.Builder(this);
                b.setMessage("Esta seguro que desea eliminar?");
                b.setCancelable(false);
                b.setPositiveButton("SI", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick (DialogInterface dialogInterface, int i){
                        Usuario usu = dao.getUsuario(u.getEmail(), u.getPassword());
                    if(dao.deteleUsuario(usu.getId())) {
                        Toast.makeText(Inicio.this, "Usuario Eliminado Correctamente", Toast.LENGTH_SHORT).show();
                        Intent intent2 = new Intent(Inicio.this, MainActivity.class);
                        intent2.putExtra("id", usu.getId());
                        startActivity(intent2);
                        finish();
                    }else{
                        Toast.makeText(Inicio.this, "Error al eliminar", Toast.LENGTH_SHORT).show();
                    }
                }
            });
                b.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                b.show();

                break;
            case R.id.btnMostrar3:
                Intent intent3= new Intent(Inicio.this, Mostrar.class);
                startActivity(intent3);
                break;
            case R.id.btnSalir3:
                Intent intent4 = new Intent(Inicio.this, MainActivity.class);
                startActivity(intent4);
                finish();
                break;

        }
    }
}
