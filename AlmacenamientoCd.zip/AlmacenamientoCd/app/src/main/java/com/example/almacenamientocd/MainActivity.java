package com.example.almacenamientocd;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    private EditText nombre;
    private EditText note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre = (EditText) findViewById(R.id.txtNombre);
        note = (EditText) findViewById(R.id.txtNote);
    }

    public void guardar(View view){
        String nombres = nombre.getText().toString();
        String notes = note.getText().toString();

        try{
            File tarjetaSD = Environment.getExternalStorageDirectory();
            Toast.makeText(this, tarjetaSD.getPath(), Toast.LENGTH_SHORT).show();
            File rutaArchivo = new File(tarjetaSD.getPath(), nombres);
            OutputStreamWriter crearArchivo = new OutputStreamWriter(openFileOutput(nombres, Activity.MODE_PRIVATE));
            crearArchivo.write(notes);
            crearArchivo.flush();
            crearArchivo.close();

            Toast.makeText(this, "Guardado correctamenete", Toast.LENGTH_SHORT).show();
            nombre.setText("");
            note.setText("");

        } catch(IOException e){
            Toast.makeText(this, "No se pudo guardar", Toast.LENGTH_SHORT).show();
        }
    }

    public void consultar (View view){
        String nom = nombre.getText().toString();

        try{
            File tarjetaCD = Environment.getExternalStorageDirectory();
            File rutaArchivo = new File(tarjetaCD.getPath(), nom);
            InputStreamReader abrirArchivo = new InputStreamReader(openFileInput(nom));

            BufferedReader leerArchivo = new BufferedReader(abrirArchivo);
            String linea = leerArchivo.readLine();
            String contenidoCompleto = "";

            while(linea != null){
                contenidoCompleto = contenidoCompleto + linea + "\n";
                linea = leerArchivo.readLine();
            }
            leerArchivo.close();
            abrirArchivo.close();
            note.setText(contenidoCompleto);

        }catch (IOException ex){
            Toast.makeText(this, "Error al leer el archivo", Toast.LENGTH_SHORT).show();
        }
    }
}


