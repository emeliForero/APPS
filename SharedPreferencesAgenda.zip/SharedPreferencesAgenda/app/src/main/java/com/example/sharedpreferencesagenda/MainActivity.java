package com.example.sharedpreferencesagenda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText txtNombre;
    private EditText txtDatos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNombre = (EditText) findViewById(R.id.txtNombre);
        txtDatos = (EditText) findViewById(R.id.txtDatos);

    }

    public void guardar(View view){
        String nombre = txtNombre.getText().toString();
        String datos = txtDatos.getText().toString();

        SharedPreferences preferences = getSharedPreferences("nombre", Context.MODE_PRIVATE);
        SharedPreferences.Editor  editor = preferences.edit();
        editor.putString(nombre,datos);
        editor.commit();

        Toast.makeText(this, "El contacto se ha guardado corrrectamente", Toast.LENGTH_SHORT).show();
    }


    public void buscar(View view){
        String nombre = txtNombre.getText().toString();
        SharedPreferences preferences = getSharedPreferences("nombre", Context.MODE_PRIVATE);
        String datos = preferences.getString(nombre, "");
        if(datos.length() == 0){
            Toast.makeText(this, "El contacto no se encontro", Toast.LENGTH_SHORT).show();
        }else{
            txtDatos.setText(datos);
        }

    }

}
